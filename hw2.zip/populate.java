import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.StringTokenizer;
	
	public class populate
	{
	    Connection mainConnection = null;
	    Statement mainStatement = null;
	    ResultSet mainResultSet = null;

	    
	    public static void main(String args[])
	    {
	        System.out.println();
			populate e = new populate(args[0],args[1],args[2]);
	        System.out.println();
	    }
	   
	    /*****************************/
	    public populate(String fName1,String fName2, String fName3)
	    {
	        ConnectToDB();			// connect to DB

	    	PublishData(fName1, fName2, fName3);			// publish some data

	    }


	    /*****************************/
	    public void PublishData(String fName1,String fName2, String fName3)
	    {
	        try
	        {
				String p;
	            String coord;
					// delete previous data from the DB
	            System.out.print( "\n ** Deleting previous tuples ..." );
	            File file=new File(fName1);
				File file1=new File(fName2);
	            File file2=new File(fName3);
	            
	            System.out.println( ", Deleting test1*" );
	            mainStatement.executeUpdate("delete from test1");
	            System.out.println( ", Deleted. **" );
	            System.out.println( ", Deleting announcements" );
	            mainStatement.executeUpdate("delete from announcementsystems");
	            System.out.println( ", Deleted. **" );
1	            System.out.println( ", Deleting buildings" );
	            mainStatement.executeUpdate("delete from buildings1");
	            System.out.println( ", Deleted. **" );
	            System.out.print( " ** Inserting Data ..." );
	            BufferedReader br = new BufferedReader( new FileReader(file));
	            BufferedReader br1=new BufferedReader(new FileReader(file1));
	            BufferedReader br2=new BufferedReader(new FileReader(file2));
	            /*read a line say l1 convert to string and
	             * String[] parts = l1.split(",");
	             * find length of parts for each line
	             * insert each row
	             */   
				 String fileName;
				 
				 System.out.println("inserting buildings");
	            while( (p = br.readLine()) != null)    
	            {    	  
	            	String[] parts=p.split(",",4);
	            	String[] parts1=parts[3].split(",");
	            		mainStatement.executeUpdate("insert into buildings1 values('"+parts[0]+"','"+parts[1]+"',"+parts[2]+","+"sdo_geometry(2003,null,null,sdo_elem_info_array(1,1003,1),sdo_ordinate_array("+parts[3]+","+parts1[0]+","+parts1[1]+")))");
	            	
	          	}
				 
				 
				 
				 
	            while( (fileName = br1.readLine()) != null)    
	            {    	            	
	            
	            	String[] parts=fileName.split(",");
	            	mainStatement.executeUpdate("Insert into test1 values('"+parts[0]+"',sdo_geometry(2001,null,sdo_point_type("+parts[1]+","+parts[2]+","+"null),null,null))");
	            	for(int k=0;k<parts.length;k++)
	            	{
	            		System.out.println(parts[k]);
	            	}
	           	}
	            System.out.println("inserting systems");
	            
	            while( (p = br2.readLine()) != null)    
	            {    	  
	            	String[] parts=p.split(",");	
	            	mainStatement.executeUpdate("Insert into announcementsystems values('"+parts[0]+"',sdo_geometry(2001,null,sdo_point_type("+parts[1]+","+parts[2]+","+"null),null,null),"+parts[3]+")");
	           	}
	            
	          
	            System.out.println( ", Done.\n **" );
	        }
	        catch( Exception e )
	        { 
	        	System.out.println( " Error 2: " + e.toString()); 
	        }
	    }
	    

	    /*****************************/
	    public void ConnectToDB()
	    {
			try
			{
				// loading Oracle Driver
	    		System.out.print("Looking for Oracle's jdbc-odbc driver ... ");
		    	DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		    	System.out.println(", Loaded.");

				String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
		    	String userName = "system";
		    	String password = "password";

		    	System.out.print("Connecting to DB...");
		    	mainConnection = DriverManager.getConnection(URL, userName, password);
		    	System.out.println(", Connected!");

	    		mainStatement = mainConnection.createStatement();

	   		}
	   		catch (Exception e)
	   		{
	     		System.out.println( "Error while connecting to DB: "+ e.toString() );
	     		e.printStackTrace();
	     		System.exit(-1);
	   		}
	    }
	}
